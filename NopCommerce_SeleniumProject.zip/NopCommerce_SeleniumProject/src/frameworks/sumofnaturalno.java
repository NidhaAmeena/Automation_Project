package frameworks;

import java.util.Scanner;

public class sumofnaturalno {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		
		int sum =0, n=10;
		
		for(int i=0;i<=n;i++)
		{
			sum =sum+i;
		}
		System.out.println("The sum of n Natuarl numbers: "+sum);
	}

}
