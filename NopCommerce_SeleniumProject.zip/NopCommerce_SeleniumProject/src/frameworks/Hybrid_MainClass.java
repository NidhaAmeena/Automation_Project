package frameworks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;



public class Hybrid_MainClass {
  
  public static void main(String[] args) throws Exception 
  {
	        //Launch Browser
			System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
			WebDriver driver =new ChromeDriver();
			//create object of readExcecelClass
			Hybrid_ReadExcelClass r=new Hybrid_ReadExcelClass();
			r.readExcel(driver);
  }
}