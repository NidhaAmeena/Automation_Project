package frameworks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class KDTMainClass 
{

	public static void main(String[] args) throws Exception
	{
		//launch browser
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		Thread.sleep(2000);

		//create object of ReadExcelClass
		KDTReadExcelClass r=new KDTReadExcelClass();
		r.readExcel(driver);

	}

}

