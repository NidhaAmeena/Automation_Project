package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPage_TitleVerification {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
				
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);
		
		//Task1: Title verification
		
		String AcceptedTitle = "nopCommerce demo store";
		String ActualTitle = driver.getTitle();
		
		if(ActualTitle.equals(AcceptedTitle))
		{
			System.out.println("Title verification Passed");
		}
		else
		{
			System.out.println("Title verification Failed");
		}
		//Task2: Navigation commands
		driver.findElement(By.xpath("//a[@href='/blog']")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
		Thread.sleep(2000);
		
		driver.navigate().forward();
		Thread.sleep(2000);
		
		driver.navigate().refresh();
		Thread.sleep(2000);
		
		driver.navigate().to("https://docs.nopcommerce.com/en/index.html");   
		Thread.sleep(2000);
		
		driver.close();

	}

}
