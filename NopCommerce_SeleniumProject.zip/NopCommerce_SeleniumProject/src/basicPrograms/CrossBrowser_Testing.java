package basicPrograms;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowser_Testing {

	public static void main(String[] args) throws InterruptedException
	{
		//Crossbrowser testing
		
				Scanner s = new Scanner(System.in);
				System.out.println("\nEnter 1 for Google Chrome\nEnter 2 for Ms Edge\nEnter 3 for Mozilla Firefox");
				int inputs = s.nextInt();
				
				WebDriver driver = null;
				
				switch(inputs)
				{
				case 1:
					System.setProperty("webdriver.chrome.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\chromedriver-win64\\chromedriver.exe");
					driver = new ChromeDriver();
					driver.manage().window().maximize();
					break;
				
				case 2:
						System.setProperty("webdriver.edge.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\msedgedriver.exe");
						driver = new EdgeDriver();
						driver.manage().window().maximize();
						break;
					
				case 3:
						System.setProperty("webdriver.gecko.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\geckodriver.exe");
						driver = new FirefoxDriver();
						driver.manage().window().maximize();
						break;
						
				default:System.out.println("Invalid Inputs");
				}
				driver.get("https://demo.nopcommerce.com/");
				
				//wait
			     Thread.sleep(2000);
			     
			     //Click on login
			     driver.findElement(By.xpath("//a[@href='/login?returnUrl=%2F']")).click();
			   //wait
			     Thread.sleep(2000);
			     
			     //Enter userName
			     driver.findElement(By.name("Email")).sendKeys("nidhakouser232@gmail.com");
			   //wait
			     Thread.sleep(2000);
			     
			     //Enter Password
			     driver.findElement(By.name("Password")).sendKeys("muddu786");
			   //wait
			     Thread.sleep(2000);
			     
			     //click login button
			     driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[4]/button")).click();
			        Thread.sleep(2000);
			        
			        //Logout
			        driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			        Thread.sleep(2000);
			        
			        driver.close();
			
			}

}


