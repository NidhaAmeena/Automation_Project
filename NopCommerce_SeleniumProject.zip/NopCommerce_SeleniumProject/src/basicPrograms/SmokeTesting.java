package basicPrograms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class SmokeTesting
{

	public static void main(String[] args) throws Exception 
	{
		
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\chromedriver-win64\\chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
			
			driver.get("https://demo.nopcommerce.com/");
			
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			
			//wait
		     Thread.sleep(2000);
		     
		     //Click on login
		     driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		   //wait
		     Thread.sleep(2000);
		     
		     //Enter userName
		     driver.findElement(By.name("Email")).sendKeys("nidhakouser232@gmail.com");
		   //wait
		     Thread.sleep(2000);
		     
		     //Enter Password
		     driver.findElement(By.name("Password")).sendKeys("muddu786");
		   //wait
		     Thread.sleep(2000);
		     
		     //click login button
		     driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
		        Thread.sleep(2000);
		        
		   
			//Click on Computers
			Thread.sleep(2000);
			driver.findElement(By.xpath("/html/body/div[6]/div[2]/ul[1]/li[1]/a")).click();
			
			
			//Mouse Hover
			//Step1: Create object of Action Class
			Actions a = new Actions(driver);
			
			//Step2: Create List for WebElements
			List<WebElement> ls = driver.findElements(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div[1]/div[2]/ul/li[1]/ul/li"));
		
			//Step3 List size >> End range which will use in FOR LOOP
			int size = ls.size();
			System.out.println("No. of Elements: "+size);
			
			//Step4 for Loop
			for(int i=1;i<=size;i++)
			{
				//wait
				Thread.sleep(2000);
				
				//Display Module name
				System.out.println(driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div[1]/div[2]/ul/li[1]/ul["+i+"]")).getText());
				
				//Perform MouseHover
				a.moveToElement(driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div[1]/div[2]/ul/li[1]/ul[\"+i+\"]"))).click().perform();
			}
			
		}


	}