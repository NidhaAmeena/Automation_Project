package mainFunctionalities;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scrolling_Screenshot 
{

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);

		JavascriptExecutor js=(JavascriptExecutor)driver;//javaScriptExecutor is an interface, that is used to execute javaScript

		//way 1: By WebElement
		//		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div/div[3]/div/div[1]/div/h2/a")).click(); 
		//		WebElement element=driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div[2]/div[2]/ul/li[1]/a"));
		//	    js.executeScript("arguments[0].scrollIntoView()", element);
		//	    
		//way 2: Pixel
		//	       js.executeScript("window.scrollBy(0,500)");
		//	       Thread.sleep(2000);
		//	        
		//way3:Bottom
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);

		//way4: Top
		//js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");
		//Thread.sleep(2000);

		//screenshot
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File(".//Screenshots//mainPage.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);//fileUtiles is a class used to copy contents of src  to specified des
		
		
		Thread.sleep(2000);
		driver.close();

	}

}

