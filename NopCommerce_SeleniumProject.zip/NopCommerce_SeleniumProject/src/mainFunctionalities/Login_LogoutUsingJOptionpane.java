package mainFunctionalities;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_LogoutUsingJOptionpane {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);


		//click on login

		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);
		//JOptionPane is a class Library that makes it easy to pop up a simple dialog box.
		//Username
		String usn=JOptionPane.showInputDialog("Enter Username");
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(usn);
		Thread.sleep(2000);

		//Password
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pwd);
		Thread.sleep(6000);

		//login
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
		Thread.sleep(2000);

		//Logout
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		driver.close();

	}

}

